function execute() {
    return Response.success([
        {title: "HOME", input: "https://www.tvtruyen.com", script: "gen.js"}
    ]);
}