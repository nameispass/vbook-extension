function execute() {
    // TVTruyen có thể không có trang thể loại, trả về rỗng
    return Response.success([]);
}